import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { DZXXGLEntity } from './entities/dzxxglentity';
import { DZXXGLProxy } from './dzxxglproxy';
var DZXXGLRepository = /** @class */ (function (_super) {
    tslib_1.__extends(DZXXGLRepository, _super);
    function DZXXGLRepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'DZXXGLRepository';
        _this.paginationInfo = {
            DZXXGLEntity: {
                pageSize: 20,
            }
        };
        _this.proxy = injector.get(DZXXGLProxy, null);
        return _this;
    }
    DZXXGLRepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/bookmanagement/gly/v1.0/dzgl_frm',
            entityType: DZXXGLEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], DZXXGLRepository);
    return DZXXGLRepository;
}(BefRepository));
export { DZXXGLRepository };
