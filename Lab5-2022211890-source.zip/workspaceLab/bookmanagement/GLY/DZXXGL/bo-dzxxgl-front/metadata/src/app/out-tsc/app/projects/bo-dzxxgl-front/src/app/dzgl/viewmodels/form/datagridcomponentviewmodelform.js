import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var DataGridComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DataGridComponentViewmodelForm, _super);
    function DataGridComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'readerid',
            name: "{{readerid_4f45cf64_ldh3}}",
            binding: 'readerid',
            updateOn: 'blur',
            defaultI18nValue: '读者编号',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "readerid", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'name',
            name: "{{name_11fb2b37_0oq9}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '读者姓名',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'age',
            name: "{{age_a539b63f_cu6b}}",
            binding: 'age',
            updateOn: 'blur',
            defaultI18nValue: '年龄',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "age", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'sexy',
            name: "{{sexy_8392be03_5m8s}}",
            binding: 'sexy',
            updateOn: 'blur',
            defaultI18nValue: '性别',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "sexy", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'phone',
            name: "{{phone_bddc3440_wh8n}}",
            binding: 'phone',
            updateOn: 'blur',
            defaultI18nValue: '联系电话',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "phone", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'department',
            name: "{{department_3b29f49b_uiad}}",
            binding: 'department',
            updateOn: 'blur',
            defaultI18nValue: '所在地',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "department", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'regdate',
            name: "{{regdate_efd7db4b_wqh3}}",
            binding: 'regdate',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '注册日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DataGridComponentViewmodelForm.prototype, "regdate", void 0);
    DataGridComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '读者信息管理',
            enableValidate: false
        }),
        Injectable()
    ], DataGridComponentViewmodelForm);
    return DataGridComponentViewmodelForm;
}(Form));
export { DataGridComponentViewmodelForm };
