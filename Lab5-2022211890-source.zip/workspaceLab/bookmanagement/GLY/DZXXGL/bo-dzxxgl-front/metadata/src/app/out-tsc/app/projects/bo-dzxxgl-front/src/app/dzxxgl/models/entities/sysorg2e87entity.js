import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var SysOrg2e87Entity = /** @class */ (function (_super) {
    tslib_1.__extends(SysOrg2e87Entity, _super);
    function SysOrg2e87Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'department',
            dataField: 'department',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'department.department',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SysOrg2e87Entity.prototype, "department", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'department_ID',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'department.department_ID',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SysOrg2e87Entity.prototype, "department_ID", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'code',
            dataField: 'department_code',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'department.department_code',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [100],
                    message: '最大长度为100',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SysOrg2e87Entity.prototype, "department_code", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'name',
            dataField: 'department_name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'department.department_name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [100],
                    message: '最大长度为100',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], SysOrg2e87Entity.prototype, "department_name", void 0);
    SysOrg2e87Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "department",
            nodeCode: "department"
        })
    ], SysOrg2e87Entity);
    return SysOrg2e87Entity;
}(Entity));
export { SysOrg2e87Entity };
