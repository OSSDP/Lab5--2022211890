import * as tslib_1 from "tslib";
import { Pipe, Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { of } from 'rxjs';
import { catchError, switchMap } from "rxjs/operators";
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
export function createTranslateLoader(http, version) {
    var versionSuffix = "";
    if (version) {
        versionSuffix = "?v=" + version;
    }
    return new TranslateHttpLoader(http, '/apps/bookmanagement/gly/web/bo-dzxxgl-front/dzxxgl/i18n/', '.json' + versionSuffix);
}
export var lang = { "zh-CHS": { "parentID_a726004e_yve3": "上级对象主键", "GridField/parentID_a726004e_yve3/editor/parentID_a726004e_jywc": "上级对象主键", "GridField/parentID_a726004e_yve3/editor/TextBox/parentID_a726004e_jywc/placeHolder": "", "TextBox/department_2e87e7ba_04p8/placeHolder": "", "LookupEdit/name_69868f83_egmb/placeHolder": "", "LookupEdit/name_69868f83_egmb/dialogTitle": "", "money_de69cedf_9by2": "所需金额", "GridField/money_de69cedf_9by2/editor/money_de69cedf_8uiz": "所需金额", "GridField/money_de69cedf_9by2/editor/NumberSpinner/money_de69cedf_8uiz/placeHolder": "", "root-component": "", "root-layout": "", "page-header": "", "header-nav": "", "header-title-container": "", "page-header-title": "", "title": "读者信息管理", "page-header-toolbar": "", "button-add": "新增", "button-edit": "编辑", "button-save": "保存", "button-cancel": "取消", "button-approve": "提交审批", "main-container": "", "like-card-container": "", "basic-form-component-ref": "", "detail-container": "", "detail-section": "", "Section/detail-section/mainTitle": "", "Section/detail-section/subTitle": "", "detail-tab": "", "jyjl-tab-page": "读者信息", "jyjl-component-ref": "", "jyjl-tab-toolbar": "", "jyjlAddButton": "新增", "jyjlRemoveButton": "删除", "tabToolbarItem-u5it": "稽核归还", "basic-form-component": "", "basic-form-section": "", "Section/basic-form-section/mainTitle": "基本信息", "Section/basic-form-section/subTitle": "", "basic-form-layout": "", "7c168e30-ba31-43cc-b411-82617444b9cd": "读者信息", "FieldSet/7c168e30-ba31-43cc-b411-82617444b9cd/collapseText": "", "FieldSet/7c168e30-ba31-43cc-b411-82617444b9cd/expandText": "", "readerid_61908cb8_a61z": "读者编号", "TextBox/readerid_61908cb8_a61z/placeHolder": "", "name_69868f83_egmb": "读者", "TextBox/name_69868f83_egmb/placeHolder": "", "age_4e87d853_3pkk": "年龄", "NumberSpinner/age_4e87d853_3pkk/placeHolder": "", "sex_78121fb9_xz6e": "性别", "EnumField/sex_78121fb9_xz6e/placeHolder": "", "EnumField/sex_78121fb9_xz6e/enumData/Nan": "男", "EnumField/sex_78121fb9_xz6e/enumData/NV": "女", "phone_fc262817_ykzn": "联系电话", "TextBox/phone_fc262817_ykzn/placeHolder": "", "department_2e87e7ba_04p8": "所在系", "LookupEdit/department_2e87e7ba_04p8/placeHolder": "", "LookupEdit/department_2e87e7ba_04p8/dialogTitle": "", "regdate_83166d2d_odej": "注册日期", "DateBox/regdate_83166d2d_odej/placeHolder": "", "jyjl-component": "", "jyjl-component-layout": "", "dataGrid_jyjl": "", "DataGrid/dataGrid_jyjl/lineNumberTitle": "", "DataGrid/dataGrid_jyjl/OperateEditButton": "编辑", "DataGrid/dataGrid_jyjl/OperateDeleteButton": "删除", "DataGrid/dataGrid_jyjl/OperateColumn": "操作", "bookid_5514a9b7_6kk7": "书籍编号", "GridField/bookid_5514a9b7_6kk7/editor/bookid_5514a9b7_5pf0": "书籍编号", "GridField/bookid_5514a9b7_6kk7/editor/TextBox/bookid_5514a9b7_5pf0/placeHolder": "", "bookname_4a5b82fd_xygz": "书名", "GridField/bookname_4a5b82fd_xygz/editor/bookname_4a5b82fd_jwc4": "书名", "GridField/bookname_4a5b82fd_xygz/editor/TextBox/bookname_4a5b82fd_jwc4/placeHolder": "", "bookname_bookname_paydate_70abc0eb_p7u0": "应还日期", "GridField/bookname_bookname_paydate_70abc0eb_p7u0/editor/bookname_bookname_paydate_70abc0eb_lbuq": "应还日期", "GridField/bookname_bookname_paydate_70abc0eb_p7u0/editor/DateBox/bookname_bookname_paydate_70abc0eb_lbuq/placeHolder": "", "bookname_bookname_author_f2713b7b_gz09": "著者", "GridField/bookname_bookname_author_f2713b7b_gz09/editor/bookname_bookname_author_f2713b7b_wsor": "著者", "GridField/bookname_bookname_author_f2713b7b_gz09/editor/TextBox/bookname_bookname_author_f2713b7b_wsor/placeHolder": "", "jysj_bc06d2b4_eqfk": "借阅时间", "GridField/jysj_bc06d2b4_eqfk/editor/jysj_bc06d2b4_0qux": "借阅时间", "GridField/jysj_bc06d2b4_eqfk/editor/DateBox/jysj_bc06d2b4_0qux/placeHolder": "", "ragtime_0ae29146_iqaa": "归还时间", "GridField/ragtime_0ae29146_iqaa/editor/ragtime_0ae29146_nr3z": "归还时间", "GridField/ragtime_0ae29146_iqaa/editor/DateBox/ragtime_0ae29146_nr3z/placeHolder": "", "ragstatus_e9db908d_zycp": "归还状态", "GridField/ragstatus_e9db908d_zycp/enumData/passed": "已归还", "GridField/ragstatus_e9db908d_zycp/enumData/defealt": "未归还" } };
var LangPipe = /** @class */ (function () {
    function LangPipe(translate, http) {
        this.translate = translate;
        this.http = http;
    }
    LangPipe.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangPipe = tslib_1.__decorate([
        Pipe({ name: 'lang' }),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], LangPipe);
    return LangPipe;
}());
export { LangPipe };
var SafeHtmlPipe = /** @class */ (function () {
    function SafeHtmlPipe(sanitizer) {
        this.sanitizer = sanitizer;
    }
    SafeHtmlPipe.prototype.transform = function (url) {
        if (!url) {
            url = "";
        }
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    };
    SafeHtmlPipe = tslib_1.__decorate([
        Pipe({ name: 'safeHtml' }),
        tslib_1.__metadata("design:paramtypes", [DomSanitizer])
    ], SafeHtmlPipe);
    return SafeHtmlPipe;
}());
export { SafeHtmlPipe };
var LangService = /** @class */ (function () {
    function LangService(translate) {
        this.translate = translate;
    }
    LangService.prototype.transform = function (key, langCode, defaultValue) {
        var translateValue = this.translate.instant(key);
        if (translateValue == "JitI18nDefaultValue") {
            return defaultValue ? defaultValue : "";
        }
        return translateValue;
    };
    LangService.prototype.getCurrentLanguage = function () {
        return this.translate.currentLang;
    };
    LangService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService])
    ], LangService);
    return LangService;
}());
export { LangService };
var TranslateResolveService = /** @class */ (function () {
    function TranslateResolveService(translate, http) {
        this.translate = translate;
        this.http = http;
        translate.defaultLang = 'zh-CHS';
        translate.setTranslation('zh-CHS', lang['zh-CHS']);
    }
    TranslateResolveService.prototype.resolve = function (route, state) {
        var _this = this;
        var langCode = localStorage.getItem('languageCode');
        if (!langCode) {
            langCode = "zh-CHS";
        }
        if (langCode == "zh-CHS" || (this.translate.defaultLang === langCode && this.translate.currentLoader == createTranslateLoader(this.http, null))) {
            this.translate.setTranslation('zh-CHS', lang['zh-CHS']);
            return of(this.translate[langCode]);
        }
        else {
            var httpOb = this.http.get("/apps/bookmanagement/gly/web/bo-dzxxgl-front/version.json?v=" + new Date().getTime()).pipe(switchMap(function (data) {
                var currentVersion = null;
                if (data instanceof Array) {
                    var versionKey_1 = "dzxxgl/" + langCode + ".json";
                    data.forEach(function (item) {
                        if (item.category == "i18n" && item.key == versionKey_1) {
                            currentVersion = item.value;
                        }
                    });
                }
                _this.translate.defaultLang = langCode;
                _this.translate.currentLang = langCode;
                _this.translate.currentLoader = createTranslateLoader(_this.http, currentVersion);
                var tran = _this.translate.getTranslation(langCode).pipe(catchError(function (err) {
                    console.error("read resource file failed,please check!!! " + err);
                    return of(err);
                }));
                return tran;
            }));
            return httpOb;
        }
    };
    TranslateResolveService = tslib_1.__decorate([
        Injectable(),
        tslib_1.__metadata("design:paramtypes", [TranslateService, HttpClient])
    ], TranslateResolveService);
    return TranslateResolveService;
}());
export { TranslateResolveService };
