import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { DZXXGL1018Entity } from './entities/dzxxgl1018entity';
import { DZXXGL1018Proxy } from './dzxxgl1018proxy';
var DZXXGL1018Repository = /** @class */ (function (_super) {
    tslib_1.__extends(DZXXGL1018Repository, _super);
    function DZXXGL1018Repository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'DZXXGL1018Repository';
        _this.paginationInfo = {};
        _this.proxy = injector.get(DZXXGL1018Proxy, null);
        return _this;
    }
    DZXXGL1018Repository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/bookmanagement/gly/v1.0/dzxxgl_frm',
            entityType: DZXXGL1018Entity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], DZXXGL1018Repository);
    return DZXXGL1018Repository;
}(BefRepository));
export { DZXXGL1018Repository };
