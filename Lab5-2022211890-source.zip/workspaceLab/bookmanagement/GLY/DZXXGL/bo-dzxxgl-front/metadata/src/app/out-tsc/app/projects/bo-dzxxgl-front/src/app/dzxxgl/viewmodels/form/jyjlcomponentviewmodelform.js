import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var JyjlComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(JyjlComponentViewmodelForm, _super);
    function JyjlComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'bookid',
            name: "{{bookid_5514a9b7_6kk7}}",
            binding: 'bookid',
            updateOn: 'blur',
            defaultI18nValue: '书籍编号',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JyjlComponentViewmodelForm.prototype, "bookid", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'bookname.bookname',
            name: "{{bookname_4a5b82fd_xygz}}",
            binding: 'bookname.bookname',
            updateOn: 'blur',
            defaultI18nValue: '书名',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JyjlComponentViewmodelForm.prototype, "bookname", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'bookname.bookname_paydate',
            name: "{{bookname_bookname_paydate_70abc0eb_p7u0}}",
            binding: 'bookname.bookname_paydate',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '应还日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JyjlComponentViewmodelForm.prototype, "bookname_bookname_paydate", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'bookname.bookname_author',
            name: "{{bookname_bookname_author_f2713b7b_gz09}}",
            binding: 'bookname.bookname_author',
            updateOn: 'blur',
            defaultI18nValue: '著者',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JyjlComponentViewmodelForm.prototype, "bookname_bookname_author", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'jysj',
            name: "{{jysj_bc06d2b4_eqfk}}",
            binding: 'jysj',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '借阅时间',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JyjlComponentViewmodelForm.prototype, "jysj", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'ragtime',
            name: "{{ragtime_0ae29146_iqaa}}",
            binding: 'ragtime',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '归还时间',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JyjlComponentViewmodelForm.prototype, "ragtime", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'ragstatus',
            name: "{{ragstatus_e9db908d_zycp}}",
            binding: 'ragstatus',
            updateOn: 'change',
            defaultI18nValue: '归还状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], JyjlComponentViewmodelForm.prototype, "ragstatus", void 0);
    JyjlComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '借阅记录',
            enableValidate: true
        }),
        Injectable()
    ], JyjlComponentViewmodelForm);
    return JyjlComponentViewmodelForm;
}(Form));
export { JyjlComponentViewmodelForm };
