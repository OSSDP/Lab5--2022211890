import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var GspUser6190Entity = /** @class */ (function (_super) {
    tslib_1.__extends(GspUser6190Entity, _super);
    function GspUser6190Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'readerid',
            dataField: 'readerid',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'readerid.readerid',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GspUser6190Entity.prototype, "readerid", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'readerid_ID',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'readerid.readerid_ID',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GspUser6190Entity.prototype, "readerid_ID", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Name',
            dataField: 'readerid_Name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'readerid.readerid_Name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GspUser6190Entity.prototype, "readerid_Name", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Code',
            dataField: 'readerid_Code',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'readerid.readerid_Code',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], GspUser6190Entity.prototype, "readerid_Code", void 0);
    GspUser6190Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "readerid",
            nodeCode: "readerid"
        })
    ], GspUser6190Entity);
    return GspUser6190Entity;
}(Entity));
export { GspUser6190Entity };
