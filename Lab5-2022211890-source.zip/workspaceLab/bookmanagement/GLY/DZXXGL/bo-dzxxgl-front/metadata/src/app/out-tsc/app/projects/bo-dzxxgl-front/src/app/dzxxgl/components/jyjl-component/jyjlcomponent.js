import * as tslib_1 from "tslib";
import { Component, Injector, ViewChild, HostBinding, ElementRef } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Form, FrameComponent, FARRIS_DEVKIT_FRAME_PROVIDERS, ViewModel, COMMAND_HANDLERS_TOKEN, FRAME_ID, BindingData, Repository, UIState, EXCEPTION_HANDLER, NAMESPACE } from '@farris/devkit';
import { FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS } from '@farris/command-services';
import { KeybindingService } from '@farris/command-services';
import { ActivatedRoute, Router } from '@angular/router';
import { FrmI18nSettingService } from '@gsp-sys/rtf-common';
import { DomSanitizer } from '@angular/platform-browser';
import { FocusInvalidService } from '@farris/command-services';
import { EditorTypes } from '@farris/ui-datagrid-editors';
import { DatagridComponent, GRID_SETTINGS_HTTP } from '@farris/ui-datagrid';
import { CommonUtils } from '@farris/ui-common';
import { BefLookupRestService, DefaultComboHttpService } from '@farris/bef';
import { ServerSideToken } from '@farris/ui-lookup';
import { ComboServerSideToken } from '@farris/ui-combo-list';
import { WizardService } from '@farris/ui-wizard';
import { LocalizationService } from "@farris/command-services";
import { JyjlComponentViewmodel } from '../../viewmodels/jyjlcomponentviewmodel';
import { DZXXGL1018Repository } from '../../models/dzxxgl1018repository';
import { LangService } from '../../lang/lang-pipe';
import { JyjlComponentViewmodelForm } from '../../viewmodels/form/jyjlcomponentviewmodelform';
import { JyjlComponentViewmodelUIState } from '../../viewmodels/uistate/jyjlcomponentviewmodeluistate';
import { jyjlAddItem1Handler } from '../../viewmodels/handlers/jyjladditem1handler';
import { jyjlRemoveItem1Handler } from '../../viewmodels/handlers/jyjlremoveitem1handler';
var JyjlComponent = /** @class */ (function (_super) {
    tslib_1.__extends(JyjlComponent, _super);
    function JyjlComponent(wizardSer, keybindingService, langService, route, router, rootElement, localizationService, frmI18nSettingService, focusInvalidService, farrisGridUtils, sanitizer, injector) {
        var _this = _super.call(this, injector) || this;
        _this.wizardSer = wizardSer;
        _this.keybindingService = keybindingService;
        _this.langService = langService;
        _this.route = route;
        _this.router = router;
        _this.rootElement = rootElement;
        _this.localizationService = localizationService;
        _this.frmI18nSettingService = frmI18nSettingService;
        _this.focusInvalidService = focusInvalidService;
        _this.farrisGridUtils = farrisGridUtils;
        _this.sanitizer = sanitizer;
        _this.injector = injector;
        _this.dataGrid_jyjlColumns = [];
        _this.cls = 'f-struct-is-subgrid ';
        _this.lang = "";
        _this.size = {};
        _this.enabledLanguageList = [];
        _this.tabsToolbarStates = new BehaviorSubject({});
        _this.tabsToolbarVisibleStates = new BehaviorSubject({});
        _this.dataGrid_jyjllineNumberTitle = _this.langService.transform("DataGrid/dataGrid_jyjl/lineNumberTitle", _this.lang, "");
        _this.lang = localStorage.getItem('languageCode') || "zh-CHS";
        _this.viewModel.verifycationChanged.subscribe(function (verifyInformations) {
            _this.focusInvalidService.focusGridCell(verifyInformations, _this.dataGrid_jyjlDataGrid);
        });
        if (_this.frmI18nSettingService) {
            var i18nSetting = _this.frmI18nSettingService.getSetting();
            if (i18nSetting && i18nSetting.languages && i18nSetting.languages.length > 0) {
                i18nSetting.languages.forEach(function (item) {
                    _this.enabledLanguageList.push({
                        code: item.code,
                        name: item.name
                    });
                });
            }
            else {
                console.warn("get current enable languages is null. if this occurs,please ensure the form into the framework.");
                _this.enabledLanguageList.push({ "code": "en", "name": "English" });
                _this.enabledLanguageList.push({ "code": "zh-CHS", "name": "中文简体" });
            }
        }
        return _this;
    }
    JyjlComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.keybindingService) {
            this.viewModel.keybindingMap.forEach(function (keyBinding, method) {
                _this.keybindingService.register(keyBinding, function () {
                    return _this.viewModel[method]();
                });
            });
        }
        this.dataGrid_jyjlColumns = [
            [
                {
                    id: 'bookid_5514a9b7_6kk7',
                    field: 'bookid',
                    width: 120,
                    title: this.langService.transform("bookid_5514a9b7_6kk7", this.lang, "书籍编号"),
                    dataType: 'string',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.TEXTBOX,
                        options: { "id": "bookid_5514a9b7_5pf0", "title": "书籍编号", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.TEXTBOX", "isPassword": false, "maxLength": 36 }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: {}
                },
                {
                    id: 'bookname_4a5b82fd_xygz',
                    field: 'bookname.bookname',
                    width: 120,
                    title: this.langService.transform("bookname_4a5b82fd_xygz", this.lang, "书名"),
                    dataType: 'string',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.TEXTBOX,
                        options: { "id": "bookname_4a5b82fd_jwc4", "title": "书名", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.TEXTBOX", "isPassword": false, "maxLength": 36 }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: {}
                },
                {
                    id: 'bookname_bookname_paydate_70abc0eb_p7u0',
                    field: 'bookname.bookname_paydate',
                    width: 120,
                    title: this.langService.transform("bookname_bookname_paydate_70abc0eb_p7u0", this.lang, "应还日期"),
                    dataType: 'date',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.DATEPICKER,
                        options: { "id": "bookname_bookname_paydate_70abc0eb_lbuq", "title": "应还日期", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.DATEPICKER", "dateRange": false, "showTime": false, "showType": 1, "dateFormat": "yyyy-MM-dd", "returnFormat": "yyyy-MM-dd", "placeholder": "", "showWeekNumbers": false, "dateRangeDatesDelimiter": "~", "editable": true, "linkedLabelEnabled": false, "linkedLabelClick": "", "hourStep": 1, "minuteStep": 1, "secondStep": 1 }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: { "type": "datetime", "options": { "format": "yyyy-MM-dd" } }
                },
                {
                    id: 'bookname_bookname_author_f2713b7b_gz09',
                    field: 'bookname.bookname_author',
                    width: 120,
                    title: this.langService.transform("bookname_bookname_author_f2713b7b_gz09", this.lang, "著者"),
                    dataType: 'string',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.TEXTBOX,
                        options: { "id": "bookname_bookname_author_f2713b7b_wsor", "title": "著者", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.TEXTBOX", "isPassword": false, "maxLength": 36 }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: {}
                },
                {
                    id: 'jysj_bc06d2b4_eqfk',
                    field: 'jysj',
                    width: 120,
                    title: this.langService.transform("jysj_bc06d2b4_eqfk", this.lang, "借阅时间"),
                    dataType: 'date',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.DATEPICKER,
                        options: { "id": "jysj_bc06d2b4_0qux", "title": "借阅时间", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.DATEPICKER", "dateRange": false, "showTime": false, "showType": 1, "dateFormat": "yyyy-MM-dd", "returnFormat": "yyyy-MM-dd", "placeholder": "", "showWeekNumbers": false, "dateRangeDatesDelimiter": "~", "editable": true, "linkedLabelEnabled": false, "linkedLabelClick": "", "hourStep": 1, "minuteStep": 1, "secondStep": 1 }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: { "type": "datetime", "options": { "format": "yyyy-MM-dd" } }
                },
                {
                    id: 'ragtime_0ae29146_iqaa',
                    field: 'ragtime',
                    width: 120,
                    title: this.langService.transform("ragtime_0ae29146_iqaa", this.lang, "归还时间"),
                    dataType: 'date',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.DATEPICKER,
                        options: { "id": "ragtime_0ae29146_nr3z", "title": "归还时间", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.DATEPICKER", "dateRange": false, "showTime": false, "showType": 1, "dateFormat": "yyyy-MM-dd", "returnFormat": "yyyy-MM-dd", "placeholder": "", "showWeekNumbers": false, "dateRangeDatesDelimiter": "~", "editable": true, "linkedLabelEnabled": false, "linkedLabelClick": "", "hourStep": 1, "minuteStep": 1, "secondStep": 1 }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: { "type": "datetime", "options": { "format": "yyyy-MM-dd" } }
                },
                {
                    id: 'ragstatus_e9db908d_zycp',
                    field: 'ragstatus',
                    width: 120,
                    title: this.langService.transform("ragstatus_e9db908d_zycp", this.lang, "归还状态"),
                    dataType: 'enum',
                    align: 'left',
                    halign: 'left',
                    valign: 'middle',
                    isMultilingualField: false,
                    editor: {
                        type: EditorTypes.COMBOLIST,
                        options: { "id": "ragstatus_e9db908d_3ela", "title": "归还状态", "placeHolder": "", "readonly": false, "localization": null, "localizationType": null, "type": "EditorTypes.COMBOLIST", "editable": false, "idField": "value", "enableClear": false, "textField": "name", "nosearch": false, "maxLength": null, "uri": "", "multiSelect": false, "data": [{ "value": "passed", "name": this.langService.transform("GridField/ragstatus_e9db908d_zycp/enumData/passed", this.lang, "已归还") }, { "value": "defealt", "name": this.langService.transform("GridField/ragstatus_e9db908d_zycp/enumData/defealt", this.lang, "未归还") }], "autoWidth": true }
                    },
                    sortable: true,
                    footer: {
                        options: {},
                    },
                    groupFooter: {
                        options: {},
                        formatter: { "type": "none" },
                    },
                    readonly: false,
                    visible: true,
                    allowGrouping: true,
                    filter: false,
                    formatter: {
                        "type": "enum",
                        "options": {
                            "valueField": "value",
                            "textField": "name",
                            "data": [
                                {
                                    "value": "passed",
                                    "name": this.langService.transform("GridField/ragstatus_e9db908d_zycp/enumData/passed", this.lang, "已归还")
                                },
                                {
                                    "value": "defealt",
                                    "name": this.langService.transform("GridField/ragstatus_e9db908d_zycp/enumData/defealt", this.lang, "未归还")
                                }
                            ]
                        }
                    }
                }
            ]
        ];
        this.viewModel.dataGrid_jyjlColumns = this.dataGrid_jyjlColumns;
        this.viewModel.dataGridColumnsName = "dataGrid_jyjlColumns";
        this.onFormLoad();
    };
    JyjlComponent.prototype.ngAfterViewInit = function () {
    };
    JyjlComponent.prototype.ngOnDestroy = function () {
        // 增加表单的自我销毁
        this.context.dispose && this.context.dispose();
        this.context = null;
        this.subscription = null;
        this.declaration = null;
        this.wizardSer = null;
        this.keybindingService = null;
        this.langService = null;
        this.route = null;
        this.router = null;
        this.rootElement = null;
        this.localizationService = null;
        this.frmI18nSettingService = null;
        this.focusInvalidService = null;
        this.farrisGridUtils = null;
        this.sanitizer = null;
        this.injector = null;
        this.enabledLanguageList = [];
    };
    JyjlComponent.prototype.handleSizeChange = function (size) {
        this.size = size;
    };
    JyjlComponent.prototype.onFormLoad = function () {
    };
    tslib_1.__decorate([
        ViewChild('dataGrid_jyjlDataGrid'),
        tslib_1.__metadata("design:type", DatagridComponent)
    ], JyjlComponent.prototype, "dataGrid_jyjlDataGrid", void 0);
    tslib_1.__decorate([
        HostBinding('class'),
        tslib_1.__metadata("design:type", Object)
    ], JyjlComponent.prototype, "cls", void 0);
    JyjlComponent = tslib_1.__decorate([
        Component({
            selector: 'app-jyjlcomponent',
            templateUrl: './jyjlcomponent.html',
            styleUrls: ['./jyjlcomponent.scss'],
            providers: [
                FARRIS_DEVKIT_FRAME_PROVIDERS,
                FARRIS_COMMAND_SERVICE_FRAME_PROVIDERS,
                { provide: FRAME_ID, useValue: 'jyjl-component' },
                { provide: BindingData, useClass: BindingData },
                { provide: Repository, useExisting: DZXXGL1018Repository },
                LangService,
                { provide: NAMESPACE, useValue: '' },
                { provide: ServerSideToken, useClass: BefLookupRestService },
                { provide: ComboServerSideToken, useClass: DefaultComboHttpService },
                { provide: GRID_SETTINGS_HTTP, useClass: BefLookupRestService },
                { provide: Form, useClass: JyjlComponentViewmodelForm },
                { provide: UIState, useClass: JyjlComponentViewmodelUIState },
                { provide: ViewModel, useClass: JyjlComponentViewmodel },
                { provide: EXCEPTION_HANDLER, useValue: null },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: jyjlAddItem1Handler, multi: true },
                { provide: COMMAND_HANDLERS_TOKEN, useClass: jyjlRemoveItem1Handler, multi: true },
            ]
        }),
        tslib_1.__metadata("design:paramtypes", [WizardService,
            KeybindingService,
            LangService,
            ActivatedRoute,
            Router,
            ElementRef,
            LocalizationService,
            FrmI18nSettingService,
            FocusInvalidService,
            CommonUtils,
            DomSanitizer,
            Injector])
    ], JyjlComponent);
    return JyjlComponent;
}(FrameComponent));
export { JyjlComponent };
