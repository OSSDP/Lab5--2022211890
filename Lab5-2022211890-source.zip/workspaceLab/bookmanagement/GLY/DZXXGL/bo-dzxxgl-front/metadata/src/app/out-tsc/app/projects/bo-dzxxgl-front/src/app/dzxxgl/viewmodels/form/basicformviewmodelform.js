import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var BasicFormViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelForm, _super);
    function BasicFormViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'readerid_61908cb8_a61z',
            name: "{{readerid_61908cb8_a61z}}",
            binding: 'readerid.readerid',
            updateOn: 'blur',
            defaultI18nValue: '读者编号',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "readerid", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'name_69868f83_egmb',
            name: "{{name_69868f83_egmb}}",
            binding: 'name',
            updateOn: 'blur',
            defaultI18nValue: '读者',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "name", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'age_4e87d853_3pkk',
            name: "{{age_4e87d853_3pkk}}",
            binding: 'age',
            updateOn: 'blur',
            defaultI18nValue: '年龄',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "age", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'sex_78121fb9_xz6e',
            name: "{{sex_78121fb9_xz6e}}",
            binding: 'sex',
            updateOn: 'change',
            defaultI18nValue: '性别',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "sex", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'phone_fc262817_ykzn',
            name: "{{phone_fc262817_ykzn}}",
            binding: 'phone',
            updateOn: 'blur',
            defaultI18nValue: '联系电话',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "phone", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'department_2e87e7ba_04p8',
            name: "{{department_2e87e7ba_04p8}}",
            binding: 'department.department',
            updateOn: 'blur',
            defaultI18nValue: '所在系',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "department", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'regdate_83166d2d_odej',
            name: "{{regdate_83166d2d_odej}}",
            binding: 'regdate',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '注册日期',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "regdate", void 0);
    BasicFormViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '读者信息管理1018',
            enableValidate: true
        }),
        Injectable()
    ], BasicFormViewmodelForm);
    return BasicFormViewmodelForm;
}(Form));
export { BasicFormViewmodelForm };
