import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, EntityList, NgList, NgEntity } from '@farris/devkit';
import { JYJLEntity } from './jyjlentity';
import { BillState6654Entity } from './billstate6654entity';
import { ProcessInstance81aaEntity } from './processinstance81aaentity';
import { GspUser6190Entity } from './gspuser6190entity';
import { SysOrg2e87Entity } from './sysorg2e87entity';
var DZXXGL1018Entity = /** @class */ (function (_super) {
    tslib_1.__extends(DZXXGL1018Entity, _super);
    function DZXXGL1018Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], DZXXGL1018Entity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], DZXXGL1018Entity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'name',
            dataField: 'name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], DZXXGL1018Entity.prototype, "name", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'age',
            dataField: 'age',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'age',
        }),
        tslib_1.__metadata("design:type", Object)
    ], DZXXGL1018Entity.prototype, "age", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'sex',
            dataField: 'sex',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'Nan',
            path: 'sex',
        }),
        tslib_1.__metadata("design:type", Object)
    ], DZXXGL1018Entity.prototype, "sex", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'phone',
            dataField: 'phone',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'phone',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], DZXXGL1018Entity.prototype, "phone", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'regdate',
            dataField: 'regdate',
            originalDataFieldType: 'Date',
            initValue: '0001-01-01T00:00:00',
            path: 'regdate',
        }),
        tslib_1.__metadata("design:type", String)
    ], DZXXGL1018Entity.prototype, "regdate", void 0);
    tslib_1.__decorate([
        NgList({
            dataField: 'jyjls',
            originalDataField: '',
            type: JYJLEntity
        }),
        tslib_1.__metadata("design:type", EntityList)
    ], DZXXGL1018Entity.prototype, "jyjls", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'billStatus',
            originalDataField: 'BillStatus',
            type: BillState6654Entity
        }),
        tslib_1.__metadata("design:type", BillState6654Entity)
    ], DZXXGL1018Entity.prototype, "billStatus", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'processInstance',
            originalDataField: 'ProcessInstance',
            type: ProcessInstance81aaEntity
        }),
        tslib_1.__metadata("design:type", ProcessInstance81aaEntity)
    ], DZXXGL1018Entity.prototype, "processInstance", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'readerid',
            originalDataField: 'readerid',
            type: GspUser6190Entity
        }),
        tslib_1.__metadata("design:type", GspUser6190Entity)
    ], DZXXGL1018Entity.prototype, "readerid", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'department',
            originalDataField: 'department',
            type: SysOrg2e87Entity
        }),
        tslib_1.__metadata("design:type", SysOrg2e87Entity)
    ], DZXXGL1018Entity.prototype, "department", void 0);
    DZXXGL1018Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "DZXXGL1018",
            nodeCode: "dzxxgL1018s"
        })
    ], DZXXGL1018Entity);
    return DZXXGL1018Entity;
}(Entity));
export { DZXXGL1018Entity };
