import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var BillState5ec6Entity = /** @class */ (function (_super) {
    tslib_1.__extends(BillState5ec6Entity, _super);
    function BillState5ec6Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'BillState',
            dataField: 'billState',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'Billing',
            path: 'BillStatus.BillState',
        }),
        tslib_1.__metadata("design:type", Object)
    ], BillState5ec6Entity.prototype, "billState", void 0);
    BillState5ec6Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "BillStatus",
            nodeCode: "billStatus"
        })
    ], BillState5ec6Entity);
    return BillState5ec6Entity;
}(Entity));
export { BillState5ec6Entity };
