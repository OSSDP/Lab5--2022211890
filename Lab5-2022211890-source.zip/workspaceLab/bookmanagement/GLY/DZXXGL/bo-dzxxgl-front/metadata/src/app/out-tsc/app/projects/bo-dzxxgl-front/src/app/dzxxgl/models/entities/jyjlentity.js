import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, NgEntity } from '@farris/devkit';
import { TSGL4a5bEntity } from './tsgl4a5bentity';
var JYJLEntity = /** @class */ (function (_super) {
    tslib_1.__extends(JYJLEntity, _super);
    function JYJLEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], JYJLEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ParentID',
            dataField: 'parentID',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ParentID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], JYJLEntity.prototype, "parentID", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'bookid',
            dataField: 'bookid',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'bookid',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], JYJLEntity.prototype, "bookid", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'jysj',
            dataField: 'jysj',
            originalDataFieldType: 'Date',
            initValue: '0001-01-01T00:00:00',
            path: 'jysj',
        }),
        tslib_1.__metadata("design:type", String)
    ], JYJLEntity.prototype, "jysj", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ragtime',
            dataField: 'ragtime',
            originalDataFieldType: 'Date',
            initValue: '0001-01-01T00:00:00',
            path: 'ragtime',
        }),
        tslib_1.__metadata("design:type", String)
    ], JYJLEntity.prototype, "ragtime", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ragstatus',
            dataField: 'ragstatus',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'passed',
            path: 'ragstatus',
        }),
        tslib_1.__metadata("design:type", Object)
    ], JYJLEntity.prototype, "ragstatus", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'author',
            dataField: 'author',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'author',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], JYJLEntity.prototype, "author", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'money',
            dataField: 'money',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'money',
        }),
        tslib_1.__metadata("design:type", Object)
    ], JYJLEntity.prototype, "money", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'bookname',
            originalDataField: 'bookname',
            type: TSGL4a5bEntity
        }),
        tslib_1.__metadata("design:type", TSGL4a5bEntity)
    ], JYJLEntity.prototype, "bookname", void 0);
    JYJLEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "JYJL",
            nodeCode: "jyjls",
            allowEmpty: true
        })
    ], JYJLEntity);
    return JYJLEntity;
}(Entity));
export { JYJLEntity };
