import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var ProcessInstanceE02EEntity = /** @class */ (function (_super) {
    tslib_1.__extends(ProcessInstanceE02EEntity, _super);
    function ProcessInstanceE02EEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ProcessInstance',
            dataField: 'processInstance',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ProcessInstance.ProcessInstance',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ProcessInstanceE02EEntity.prototype, "processInstance", void 0);
    ProcessInstanceE02EEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "ProcessInstance",
            nodeCode: "processInstance"
        })
    ], ProcessInstanceE02EEntity);
    return ProcessInstanceE02EEntity;
}(Entity));
export { ProcessInstanceE02EEntity };
