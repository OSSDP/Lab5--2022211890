import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var DZXXGLEntity = /** @class */ (function (_super) {
    tslib_1.__extends(DZXXGLEntity, _super);
    function DZXXGLEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], DZXXGLEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], DZXXGLEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Readerid',
            dataField: 'readerid',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'Readerid',
        }),
        tslib_1.__metadata("design:type", Object)
    ], DZXXGLEntity.prototype, "readerid", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'name',
            dataField: 'name',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'name',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], DZXXGLEntity.prototype, "name", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'age',
            dataField: 'age',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'age',
        }),
        tslib_1.__metadata("design:type", Object)
    ], DZXXGLEntity.prototype, "age", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'sexy',
            dataField: 'sexy',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'sexy',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], DZXXGLEntity.prototype, "sexy", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'phone',
            dataField: 'phone',
            originalDataFieldType: 'Number',
            initValue: 0,
            path: 'phone',
        }),
        tslib_1.__metadata("design:type", Object)
    ], DZXXGLEntity.prototype, "phone", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'department',
            dataField: 'department',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'department',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], DZXXGLEntity.prototype, "department", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'regdate',
            dataField: 'regdate',
            originalDataFieldType: 'Date',
            initValue: '0001-01-01T00:00:00',
            path: 'regdate',
        }),
        tslib_1.__metadata("design:type", String)
    ], DZXXGLEntity.prototype, "regdate", void 0);
    DZXXGLEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "DZXXGL",
            nodeCode: "dzxxgls"
        })
    ], DZXXGLEntity);
    return DZXXGLEntity;
}(Entity));
export { DZXXGLEntity };
