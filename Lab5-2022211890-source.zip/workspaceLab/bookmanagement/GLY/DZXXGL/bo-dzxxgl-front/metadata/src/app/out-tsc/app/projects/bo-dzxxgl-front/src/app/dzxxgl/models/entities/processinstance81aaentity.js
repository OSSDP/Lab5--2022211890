import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var ProcessInstance81aaEntity = /** @class */ (function (_super) {
    tslib_1.__extends(ProcessInstance81aaEntity, _super);
    function ProcessInstance81aaEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ProcessInstance',
            dataField: 'processInstance',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ProcessInstance.ProcessInstance',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ProcessInstance81aaEntity.prototype, "processInstance", void 0);
    ProcessInstance81aaEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "ProcessInstance",
            nodeCode: "processInstance"
        })
    ], ProcessInstance81aaEntity);
    return ProcessInstance81aaEntity;
}(Entity));
export { ProcessInstance81aaEntity };
