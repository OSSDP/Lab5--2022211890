import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var TSGL4a5bEntity = /** @class */ (function (_super) {
    tslib_1.__extends(TSGL4a5bEntity, _super);
    function TSGL4a5bEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'bookname',
            dataField: 'bookname',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'bookname.bookname',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], TSGL4a5bEntity.prototype, "bookname", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Title',
            dataField: 'bookname_Title',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'bookname.bookname_Title',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], TSGL4a5bEntity.prototype, "bookname_Title", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ISBN',
            dataField: 'bookname_ISBN',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'bookname.bookname_ISBN',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], TSGL4a5bEntity.prototype, "bookname_ISBN", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'paydate',
            dataField: 'bookname_paydate',
            originalDataFieldType: 'Date',
            initValue: '0001-01-01T00:00:00',
            path: 'bookname.bookname_paydate',
        }),
        tslib_1.__metadata("design:type", String)
    ], TSGL4a5bEntity.prototype, "bookname_paydate", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'author',
            dataField: 'bookname_author',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'bookname.bookname_author',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], TSGL4a5bEntity.prototype, "bookname_author", void 0);
    TSGL4a5bEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "bookname",
            nodeCode: "bookname"
        })
    ], TSGL4a5bEntity);
    return TSGL4a5bEntity;
}(Entity));
export { TSGL4a5bEntity };
