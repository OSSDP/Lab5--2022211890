import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var ProcessInstance5b62Entity = /** @class */ (function (_super) {
    tslib_1.__extends(ProcessInstance5b62Entity, _super);
    function ProcessInstance5b62Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ProcessInstance',
            dataField: 'processInstance',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ProcessInstance.ProcessInstance',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ProcessInstance5b62Entity.prototype, "processInstance", void 0);
    ProcessInstance5b62Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "ProcessInstance",
            nodeCode: "processInstance"
        })
    ], ProcessInstance5b62Entity);
    return ProcessInstance5b62Entity;
}(Entity));
export { ProcessInstance5b62Entity };
