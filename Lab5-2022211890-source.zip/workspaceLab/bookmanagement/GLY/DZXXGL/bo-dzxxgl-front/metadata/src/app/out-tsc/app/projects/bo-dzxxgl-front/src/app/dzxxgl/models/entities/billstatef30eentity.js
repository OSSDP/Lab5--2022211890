import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var BillStateF30eEntity = /** @class */ (function (_super) {
    tslib_1.__extends(BillStateF30eEntity, _super);
    function BillStateF30eEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'BillState',
            dataField: 'billState',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'Billing',
            path: 'BillStatus.BillState',
        }),
        tslib_1.__metadata("design:type", Object)
    ], BillStateF30eEntity.prototype, "billState", void 0);
    BillStateF30eEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "BillStatus",
            nodeCode: "billStatus"
        })
    ], BillStateF30eEntity);
    return BillStateF30eEntity;
}(Entity));
export { BillStateF30eEntity };
