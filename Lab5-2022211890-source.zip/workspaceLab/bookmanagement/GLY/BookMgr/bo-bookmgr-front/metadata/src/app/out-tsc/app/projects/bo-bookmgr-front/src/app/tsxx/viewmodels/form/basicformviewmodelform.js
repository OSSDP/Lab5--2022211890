import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var BasicFormViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelForm, _super);
    function BasicFormViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'bookname_b36c677f_z1uy',
            name: "{{bookname_b36c677f_z1uy}}",
            binding: 'bookname',
            updateOn: 'blur',
            defaultI18nValue: '名称',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "bookname", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'bookcategories_6f3c0067_7ngs',
            name: "{{bookcategories_6f3c0067_7ngs}}",
            binding: 'bookcategories',
            updateOn: 'blur',
            defaultI18nValue: '图书分类',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "bookcategories", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'author_3bfe07ea_nfoj',
            name: "{{author_3bfe07ea_nfoj}}",
            binding: 'author',
            updateOn: 'blur',
            defaultI18nValue: '作者',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "author", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'status_f6cfdbfc_9jxc',
            name: "{{status_f6cfdbfc_9jxc}}",
            binding: 'curtstatus',
            updateOn: 'change',
            defaultI18nValue: '目前状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "curtstatus", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'chubandate_36058630_x5jj',
            name: "{{chubandate_36058630_x5jj}}",
            binding: 'chubandate',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '出版日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "chubandate", void 0);
    BasicFormViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '图书信息管理',
            enableValidate: true
        }),
        Injectable()
    ], BasicFormViewmodelForm);
    return BasicFormViewmodelForm;
}(Form));
export { BasicFormViewmodelForm };
