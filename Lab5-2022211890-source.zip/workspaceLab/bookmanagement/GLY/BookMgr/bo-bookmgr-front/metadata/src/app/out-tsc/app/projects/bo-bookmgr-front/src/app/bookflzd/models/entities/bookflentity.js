import * as tslib_1 from "tslib";
import { Entity, NgField, NgObject, NgEntity } from '@farris/devkit';
import { BillState74a9Entity } from './billstate74a9entity';
import { ProcessInstance073bEntity } from './processinstance073bentity';
var BookFLEntity = /** @class */ (function (_super) {
    tslib_1.__extends(BookFLEntity, _super);
    function BookFLEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Version',
            dataField: 'version',
            originalDataFieldType: 'DateTime',
            initValue: '0001-01-01T00:00:00',
            path: 'Version',
            enableTimeZone: true,
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "version", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'MarxismLeninism',
            dataField: 'marxismLeninism',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'MarxismLeninism',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "marxismLeninism", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Philosophyreligion',
            dataField: 'philosophyreligion',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Philosophyreligion',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "philosophyreligion", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'SocialSciences',
            dataField: 'socialSciences',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'SocialSciences',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "socialSciences", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Politicallaw',
            dataField: 'politicallaw',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Politicallaw',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "politicallaw", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'militaryaffairs',
            dataField: 'militaryaffairs',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'militaryaffairs',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "militaryaffairs", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'economy',
            dataField: 'economy',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'economy',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "economy", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'culture',
            dataField: 'culture',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'culture',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "culture", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Languages',
            dataField: 'languages',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Languages',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "languages", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'literature',
            dataField: 'literature',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'literature',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "literature", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'art',
            dataField: 'art',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'art',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "art", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'historygeographically',
            dataField: 'historygeographically',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'historygeographically',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "historygeographically", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ntroductiontoNaturalScience',
            dataField: 'ntroductiontoNaturalScience',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ntroductiontoNaturalScience',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "ntroductiontoNaturalScience", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'MathematicalChemistry',
            dataField: 'mathematicalChemistry',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'MathematicalChemistry',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "mathematicalChemistry", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'AstronomyEarthScience',
            dataField: 'astronomyEarthScience',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'AstronomyEarthScience',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "astronomyEarthScience", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'biological',
            dataField: 'biological',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'biological',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "biological", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'MedicineHealth',
            dataField: 'medicineHealth',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'MedicineHealth',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "medicineHealth", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Agriculture',
            dataField: 'agriculture',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Agriculture',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "agriculture", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'technology',
            dataField: 'technology',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'technology',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "technology", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Transportation',
            dataField: 'transportation',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Transportation',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "transportation", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Aerospace',
            dataField: 'aerospace',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Aerospace',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "aerospace", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'EnvironmentalSafety',
            dataField: 'environmentalSafety',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'EnvironmentalSafety',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "environmentalSafety", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Comprehensivebooks',
            dataField: 'comprehensivebooks',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'Comprehensivebooks',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "comprehensivebooks", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'booklbname',
            dataField: 'booklbname',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'booklbname',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "booklbname", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'booklbcode',
            dataField: 'booklbcode',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'booklbcode',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookFLEntity.prototype, "booklbcode", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Remark',
            dataField: 'remark',
            originalDataFieldType: 'Text',
            initValue: '',
            path: 'Remark',
        }),
        tslib_1.__metadata("design:type", Object)
    ], BookFLEntity.prototype, "remark", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'billStatus',
            originalDataField: 'BillStatus',
            type: BillState74a9Entity
        }),
        tslib_1.__metadata("design:type", BillState74a9Entity)
    ], BookFLEntity.prototype, "billStatus", void 0);
    tslib_1.__decorate([
        NgObject({
            dataField: 'processInstance',
            originalDataField: 'ProcessInstance',
            type: ProcessInstance073bEntity
        }),
        tslib_1.__metadata("design:type", ProcessInstance073bEntity)
    ], BookFLEntity.prototype, "processInstance", void 0);
    BookFLEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "BookFL",
            nodeCode: "bookFLs"
        })
    ], BookFLEntity);
    return BookFLEntity;
}(Entity));
export { BookFLEntity };
