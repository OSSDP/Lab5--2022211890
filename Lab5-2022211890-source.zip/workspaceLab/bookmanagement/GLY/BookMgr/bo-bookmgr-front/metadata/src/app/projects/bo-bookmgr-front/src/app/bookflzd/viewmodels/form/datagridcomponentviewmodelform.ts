
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '图书分类',
    enableValidate: false
})

@Injectable()
export class DataGridComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'booklbname',
        name: "{{booklbname_707c1bb4_wklx}}",
        binding: 'booklbname',
        updateOn: 'blur',
        defaultI18nValue: '图书类别名称',
    })
    booklbname: FormControl;

}