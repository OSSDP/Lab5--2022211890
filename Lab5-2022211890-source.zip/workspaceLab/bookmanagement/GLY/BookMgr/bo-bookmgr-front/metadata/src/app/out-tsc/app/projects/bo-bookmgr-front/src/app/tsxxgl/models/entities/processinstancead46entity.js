import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var ProcessInstanceAd46Entity = /** @class */ (function (_super) {
    tslib_1.__extends(ProcessInstanceAd46Entity, _super);
    function ProcessInstanceAd46Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ProcessInstance',
            dataField: 'processInstance',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ProcessInstance.ProcessInstance',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], ProcessInstanceAd46Entity.prototype, "processInstance", void 0);
    ProcessInstanceAd46Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "ProcessInstance",
            nodeCode: "processInstance"
        })
    ], ProcessInstanceAd46Entity);
    return ProcessInstanceAd46Entity;
}(Entity));
export { ProcessInstanceAd46Entity };
