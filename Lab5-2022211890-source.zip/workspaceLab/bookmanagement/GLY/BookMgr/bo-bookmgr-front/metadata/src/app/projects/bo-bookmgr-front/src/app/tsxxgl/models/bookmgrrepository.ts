
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository, NgVariable } from '@farris/bef';
import { BookMgrEntity } from './entities/bookmgrentity';

import { BookMgrProxy } from './bookmgrproxy';

@Injectable()
@NgRepository({
    apiUrl: 'api/bookmanagement/gly/v1.0/tsxxgl_frm',
    entityType: BookMgrEntity
})
export class BookMgrRepository extends BefRepository<BookMgrEntity> {
    public name = 'BookMgrRepository';

    public proxy: BookMgrProxy;
    public paginationInfo = {
    };
    constructor(injector: Injector) {
        super(injector);
        this.proxy = injector.get(BookMgrProxy, null);
    }
}