
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '图书分类',
    enableValidate: true
})

@Injectable()
export class DetailFormComponentViewmodelForm extends Form {
    @NgFormControl({
        id: 'booklbname_707c1bb4_kdt4',
        name: "{{booklbname_707c1bb4_kdt4}}",
        binding: 'booklbname',
        updateOn: 'blur',
        defaultI18nValue: '图书类别名称',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    booklbname: FormControl;

    @NgFormControl({
        id: 'booklbcode_b9bc3b63_6bc0',
        name: "{{booklbcode_b9bc3b63_6bc0}}",
        binding: 'booklbcode',
        updateOn: 'blur',
        defaultI18nValue: '图书类别编号',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    booklbcode: FormControl;

    @NgFormControl({
        id: 'remark_efe474e2_dupt',
        name: "{{remark_efe474e2_dupt}}",
        binding: 'remark',
        updateOn: 'blur',
        defaultI18nValue: '备注',
    })
    remark: FormControl;

}