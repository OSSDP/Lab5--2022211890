
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';
import { BillState7c14Entity } from './billstate7c14entity';
import { ProcessInstanceAd46Entity } from './processinstancead46entity';

@NgEntity({
    originalCode: "BookMgr",
    nodeCode: "bookMgrs"
})
export class BookMgrEntity extends Entity {

    @NgField({
        originalDataField: 'ID',
        dataField: 'id',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ID',

        validRules: [
            {
                type: 'required',
                constraints: [true],
            },
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    id: string;

    @NgField({
        originalDataField: 'Version',
        dataField: 'version',
        originalDataFieldType: 'DateTime',
        initValue: '0001-01-01T00:00:00',
        path: 'Version',
        enableTimeZone: true,
    })
    version: string;

    @NgField({
        originalDataField: 'bookid',
        dataField: 'bookid',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'bookid',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    bookid: string;

    @NgField({
        originalDataField: 'bookname',
        dataField: 'bookname',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'bookname',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    bookname: string;

    @NgField({
        originalDataField: 'bookcategories',
        dataField: 'bookcategories',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'bookcategories',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    bookcategories: string;

    @NgField({
        originalDataField: 'author',
        dataField: 'author',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'author',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    author: string;

    @NgField({
        originalDataField: 'Curtstatus',
        dataField: 'curtstatus',
        originalDataFieldType: 'Enum',
        defaultValue: '',
        initValue: 'pass',
        path: 'Curtstatus',
    })
    curtstatus: any;

    @NgField({
        originalDataField: 'chubandate',
        dataField: 'chubandate',
        originalDataFieldType: 'Date',
        initValue: '0001-01-01T00:00:00',
        path: 'chubandate',
    })
    chubandate: string;

    @NgObject({
        dataField: 'billStatus',
        originalDataField: 'BillStatus',
        type: BillState7c14Entity
    })
    billStatus: BillState7c14Entity;
    @NgObject({
        dataField: 'processInstance',
        originalDataField: 'ProcessInstance',
        type: ProcessInstanceAd46Entity
    })
    processInstance: ProcessInstanceAd46Entity;
}