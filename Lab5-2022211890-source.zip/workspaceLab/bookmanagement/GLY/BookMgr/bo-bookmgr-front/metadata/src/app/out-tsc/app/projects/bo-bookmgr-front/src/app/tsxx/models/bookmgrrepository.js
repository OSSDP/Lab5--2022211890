import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { BookMgrEntity } from './entities/bookmgrentity';
import { BookMgrProxy } from './bookmgrproxy';
var BookMgrRepository = /** @class */ (function (_super) {
    tslib_1.__extends(BookMgrRepository, _super);
    function BookMgrRepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'BookMgrRepository';
        _this.paginationInfo = {};
        _this.proxy = injector.get(BookMgrProxy, null);
        return _this;
    }
    BookMgrRepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/bookmanagement/gly/v1.0/tsxx_frm',
            entityType: BookMgrEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], BookMgrRepository);
    return BookMgrRepository;
}(BefRepository));
export { BookMgrRepository };
