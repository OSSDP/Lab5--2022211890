
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgChildForm, NgChildFormArray, NgValidateForm } from '@farris/devkit';
import { DateConverter, MultiLangConverter } from '@farris/kendo-binding';

@Injectable()
@NgValidateForm({
    formGroupName: '图书信息管理',
    enableValidate: true
})

@Injectable()
export class BasicFormViewmodelForm extends Form {
    @NgFormControl({
        id: 'bookid_56d54438_37p9',
        name: "{{bookid_56d54438_37p9}}",
        binding: 'bookid',
        updateOn: 'blur',
        defaultI18nValue: '编号',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    bookid: FormControl;

    @NgFormControl({
        id: 'bookname_d4be1e84_orrj',
        name: "{{bookname_d4be1e84_orrj}}",
        binding: 'bookname',
        updateOn: 'blur',
        defaultI18nValue: '名称',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    bookname: FormControl;

    @NgFormControl({
        id: 'bookcategories_dd17bbb0_rvio',
        name: "{{bookcategories_dd17bbb0_rvio}}",
        binding: 'bookcategories',
        updateOn: 'blur',
        defaultI18nValue: '图书分类',
    })
    bookcategories: FormControl;

    @NgFormControl({
        id: 'author_22364c01_feym',
        name: "{{author_22364c01_feym}}",
        binding: 'author',
        updateOn: 'blur',
        defaultI18nValue: '作者',
        validRules: [
            {
                type: 'matches',
                constraints: [''],
            }
        ]
    })
    author: FormControl;

    @NgFormControl({
        id: 'curtstatus_dcd5223b_8s0r',
        name: "{{curtstatus_dcd5223b_8s0r}}",
        binding: 'curtstatus',
        updateOn: 'change',
        defaultI18nValue: '目前状态',
    })
    curtstatus: FormControl;

    @NgFormControl({
        id: 'chubandate_afe65f29_9s5u',
        name: "{{chubandate_afe65f29_9s5u}}",
        binding: 'chubandate',
        updateOn: 'blur',
        valueConverter: new DateConverter('yyyy-MM-dd'),
        defaultI18nValue: '出版日期',
    })
    chubandate: FormControl;

}