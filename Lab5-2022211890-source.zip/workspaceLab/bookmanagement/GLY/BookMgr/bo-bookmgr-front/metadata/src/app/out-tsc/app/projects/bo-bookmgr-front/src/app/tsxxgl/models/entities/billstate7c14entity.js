import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var BillState7c14Entity = /** @class */ (function (_super) {
    tslib_1.__extends(BillState7c14Entity, _super);
    function BillState7c14Entity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'BillState',
            dataField: 'billState',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'Billing',
            path: 'BillStatus.BillState',
        }),
        tslib_1.__metadata("design:type", Object)
    ], BillState7c14Entity.prototype, "billState", void 0);
    BillState7c14Entity = tslib_1.__decorate([
        NgEntity({
            originalCode: "BillStatus",
            nodeCode: "billStatus"
        })
    ], BillState7c14Entity);
    return BillState7c14Entity;
}(Entity));
export { BillState7c14Entity };
