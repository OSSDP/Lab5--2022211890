import * as tslib_1 from "tslib";
import { Entity, NgField, NgEntity } from '@farris/devkit';
var BookMgrEntity = /** @class */ (function (_super) {
    tslib_1.__extends(BookMgrEntity, _super);
    function BookMgrEntity() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgField({
            originalDataField: 'ID',
            dataField: 'id',
            primary: true,
            originalDataFieldType: 'String',
            initValue: '',
            path: 'ID',
            validRules: [
                {
                    type: 'required',
                    constraints: [true],
                },
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookMgrEntity.prototype, "id", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'bookid',
            dataField: 'bookid',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'bookid',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookMgrEntity.prototype, "bookid", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'bookname',
            dataField: 'bookname',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'bookname',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookMgrEntity.prototype, "bookname", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'bookcategories',
            dataField: 'bookcategories',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'bookcategories',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookMgrEntity.prototype, "bookcategories", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'author',
            dataField: 'author',
            originalDataFieldType: 'String',
            initValue: '',
            path: 'author',
            validRules: [
                {
                    type: 'maxLength',
                    constraints: [36],
                    message: '最大长度为36',
                }
            ]
        }),
        tslib_1.__metadata("design:type", String)
    ], BookMgrEntity.prototype, "author", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'Curtstatus',
            dataField: 'curtstatus',
            originalDataFieldType: 'Enum',
            defaultValue: '',
            initValue: 'pass',
            path: 'Curtstatus',
        }),
        tslib_1.__metadata("design:type", Object)
    ], BookMgrEntity.prototype, "curtstatus", void 0);
    tslib_1.__decorate([
        NgField({
            originalDataField: 'chubandate',
            dataField: 'chubandate',
            originalDataFieldType: 'Date',
            initValue: '0001-01-01T00:00:00',
            path: 'chubandate',
        }),
        tslib_1.__metadata("design:type", String)
    ], BookMgrEntity.prototype, "chubandate", void 0);
    BookMgrEntity = tslib_1.__decorate([
        NgEntity({
            originalCode: "BookMgr",
            nodeCode: "bookMgrs"
        })
    ], BookMgrEntity);
    return BookMgrEntity;
}(Entity));
export { BookMgrEntity };
