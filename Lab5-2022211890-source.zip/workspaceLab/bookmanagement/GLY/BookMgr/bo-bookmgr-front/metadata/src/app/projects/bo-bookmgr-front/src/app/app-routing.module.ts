import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
const routes: Routes = [
  { path: 'BookFLZD', loadChildren:'./bookflzd/bookflzd#BookFLZDModule'},
  { path: 'TSXXGL', loadChildren:'./tsxxgl/tsxxgl#TSXXGLModule'}
];
@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true })],
    exports: [RouterModule]
})
export class AppRoutingModule { }