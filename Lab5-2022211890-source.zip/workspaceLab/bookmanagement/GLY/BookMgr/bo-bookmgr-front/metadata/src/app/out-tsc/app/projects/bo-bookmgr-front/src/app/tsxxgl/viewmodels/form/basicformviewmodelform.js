import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
import { DateConverter } from '@farris/kendo-binding';
var BasicFormViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(BasicFormViewmodelForm, _super);
    function BasicFormViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'bookid_56d54438_37p9',
            name: "{{bookid_56d54438_37p9}}",
            binding: 'bookid',
            updateOn: 'blur',
            defaultI18nValue: '编号',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "bookid", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'bookname_d4be1e84_orrj',
            name: "{{bookname_d4be1e84_orrj}}",
            binding: 'bookname',
            updateOn: 'blur',
            defaultI18nValue: '名称',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "bookname", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'bookcategories_dd17bbb0_rvio',
            name: "{{bookcategories_dd17bbb0_rvio}}",
            binding: 'bookcategories',
            updateOn: 'blur',
            defaultI18nValue: '图书分类',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "bookcategories", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'author_22364c01_feym',
            name: "{{author_22364c01_feym}}",
            binding: 'author',
            updateOn: 'blur',
            defaultI18nValue: '作者',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "author", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'curtstatus_dcd5223b_8s0r',
            name: "{{curtstatus_dcd5223b_8s0r}}",
            binding: 'curtstatus',
            updateOn: 'change',
            defaultI18nValue: '目前状态',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "curtstatus", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'chubandate_afe65f29_9s5u',
            name: "{{chubandate_afe65f29_9s5u}}",
            binding: 'chubandate',
            updateOn: 'blur',
            valueConverter: new DateConverter('yyyy-MM-dd'),
            defaultI18nValue: '出版日期',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], BasicFormViewmodelForm.prototype, "chubandate", void 0);
    BasicFormViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '图书信息管理',
            enableValidate: true
        }),
        Injectable()
    ], BasicFormViewmodelForm);
    return BasicFormViewmodelForm;
}(Form));
export { BasicFormViewmodelForm };
