import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Form, NgFormControl, NgValidateForm } from '@farris/devkit';
var DetailFormComponentViewmodelForm = /** @class */ (function (_super) {
    tslib_1.__extends(DetailFormComponentViewmodelForm, _super);
    function DetailFormComponentViewmodelForm() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    tslib_1.__decorate([
        NgFormControl({
            id: 'booklbname_707c1bb4_kdt4',
            name: "{{booklbname_707c1bb4_kdt4}}",
            binding: 'booklbname',
            updateOn: 'blur',
            defaultI18nValue: '图书类别名称',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "booklbname", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'booklbcode_b9bc3b63_6bc0',
            name: "{{booklbcode_b9bc3b63_6bc0}}",
            binding: 'booklbcode',
            updateOn: 'blur',
            defaultI18nValue: '图书类别编号',
            validRules: [
                {
                    type: 'matches',
                    constraints: [''],
                }
            ]
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "booklbcode", void 0);
    tslib_1.__decorate([
        NgFormControl({
            id: 'remark_efe474e2_dupt',
            name: "{{remark_efe474e2_dupt}}",
            binding: 'remark',
            updateOn: 'blur',
            defaultI18nValue: '备注',
        }),
        tslib_1.__metadata("design:type", FormControl)
    ], DetailFormComponentViewmodelForm.prototype, "remark", void 0);
    DetailFormComponentViewmodelForm = tslib_1.__decorate([
        Injectable(),
        NgValidateForm({
            formGroupName: '图书分类',
            enableValidate: true
        }),
        Injectable()
    ], DetailFormComponentViewmodelForm);
    return DetailFormComponentViewmodelForm;
}(Form));
export { DetailFormComponentViewmodelForm };
