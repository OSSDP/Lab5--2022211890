import * as tslib_1 from "tslib";
import { Injectable, Injector } from '@angular/core';
import { NgRepository } from '@farris/devkit';
import { BefRepository } from '@farris/bef';
import { BookFLEntity } from './entities/bookflentity';
import { BookFLProxy } from './bookflproxy';
var BookFLRepository = /** @class */ (function (_super) {
    tslib_1.__extends(BookFLRepository, _super);
    function BookFLRepository(injector) {
        var _this = _super.call(this, injector) || this;
        _this.name = 'BookFLRepository';
        _this.paginationInfo = {
            BookFLEntity: {
                pageSize: 20,
            }
        };
        _this.proxy = injector.get(BookFLProxy, null);
        return _this;
    }
    BookFLRepository = tslib_1.__decorate([
        Injectable(),
        NgRepository({
            apiUrl: 'api/bookmanagement/gly/v1.0/bookflzd_frm',
            entityType: BookFLEntity
        }),
        tslib_1.__metadata("design:paramtypes", [Injector])
    ], BookFLRepository);
    return BookFLRepository;
}(BefRepository));
export { BookFLRepository };
