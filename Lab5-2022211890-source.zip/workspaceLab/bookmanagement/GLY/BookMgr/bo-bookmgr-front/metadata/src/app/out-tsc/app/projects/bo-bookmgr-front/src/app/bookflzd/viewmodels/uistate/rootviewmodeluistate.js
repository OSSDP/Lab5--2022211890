import * as tslib_1 from "tslib";
import { Injectable } from '@angular/core';
import { UIState } from '@farris/devkit';
var RootViewmodelUIState = /** @class */ (function (_super) {
    tslib_1.__extends(RootViewmodelUIState, _super);
    function RootViewmodelUIState() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    RootViewmodelUIState = tslib_1.__decorate([
        Injectable()
    ], RootViewmodelUIState);
    return RootViewmodelUIState;
}(UIState));
export { RootViewmodelUIState };
