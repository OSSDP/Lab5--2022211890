
import { Entity, NgField, NgObject, EntityList, NgList, NgDynamic, DynamicEntity, NgEntity } from '@farris/devkit';
import { BillState74a9Entity } from './billstate74a9entity';
import { ProcessInstance073bEntity } from './processinstance073bentity';

@NgEntity({
    originalCode: "BookFL",
    nodeCode: "bookFLs"
})
export class BookFLEntity extends Entity {

    @NgField({
        originalDataField: 'ID',
        dataField: 'id',
        primary: true,
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ID',

        validRules: [
            {
                type: 'required',
                constraints: [true],
            },
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    id: string;

    @NgField({
        originalDataField: 'Version',
        dataField: 'version',
        originalDataFieldType: 'DateTime',
        initValue: '0001-01-01T00:00:00',
        path: 'Version',
        enableTimeZone: true,
    })
    version: string;

    @NgField({
        originalDataField: 'MarxismLeninism',
        dataField: 'marxismLeninism',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'MarxismLeninism',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    marxismLeninism: string;

    @NgField({
        originalDataField: 'Philosophyreligion',
        dataField: 'philosophyreligion',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Philosophyreligion',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    philosophyreligion: string;

    @NgField({
        originalDataField: 'SocialSciences',
        dataField: 'socialSciences',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'SocialSciences',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    socialSciences: string;

    @NgField({
        originalDataField: 'Politicallaw',
        dataField: 'politicallaw',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Politicallaw',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    politicallaw: string;

    @NgField({
        originalDataField: 'militaryaffairs',
        dataField: 'militaryaffairs',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'militaryaffairs',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    militaryaffairs: string;

    @NgField({
        originalDataField: 'economy',
        dataField: 'economy',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'economy',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    economy: string;

    @NgField({
        originalDataField: 'culture',
        dataField: 'culture',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'culture',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    culture: string;

    @NgField({
        originalDataField: 'Languages',
        dataField: 'languages',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Languages',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    languages: string;

    @NgField({
        originalDataField: 'literature',
        dataField: 'literature',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'literature',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    literature: string;

    @NgField({
        originalDataField: 'art',
        dataField: 'art',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'art',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    art: string;

    @NgField({
        originalDataField: 'historygeographically',
        dataField: 'historygeographically',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'historygeographically',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    historygeographically: string;

    @NgField({
        originalDataField: 'ntroductiontoNaturalScience',
        dataField: 'ntroductiontoNaturalScience',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'ntroductiontoNaturalScience',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    ntroductiontoNaturalScience: string;

    @NgField({
        originalDataField: 'MathematicalChemistry',
        dataField: 'mathematicalChemistry',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'MathematicalChemistry',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    mathematicalChemistry: string;

    @NgField({
        originalDataField: 'AstronomyEarthScience',
        dataField: 'astronomyEarthScience',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'AstronomyEarthScience',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    astronomyEarthScience: string;

    @NgField({
        originalDataField: 'biological',
        dataField: 'biological',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'biological',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    biological: string;

    @NgField({
        originalDataField: 'MedicineHealth',
        dataField: 'medicineHealth',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'MedicineHealth',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    medicineHealth: string;

    @NgField({
        originalDataField: 'Agriculture',
        dataField: 'agriculture',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Agriculture',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    agriculture: string;

    @NgField({
        originalDataField: 'technology',
        dataField: 'technology',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'technology',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    technology: string;

    @NgField({
        originalDataField: 'Transportation',
        dataField: 'transportation',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Transportation',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    transportation: string;

    @NgField({
        originalDataField: 'Aerospace',
        dataField: 'aerospace',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Aerospace',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    aerospace: string;

    @NgField({
        originalDataField: 'EnvironmentalSafety',
        dataField: 'environmentalSafety',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'EnvironmentalSafety',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    environmentalSafety: string;

    @NgField({
        originalDataField: 'Comprehensivebooks',
        dataField: 'comprehensivebooks',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'Comprehensivebooks',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    comprehensivebooks: string;

    @NgField({
        originalDataField: 'booklbname',
        dataField: 'booklbname',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'booklbname',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    booklbname: string;

    @NgField({
        originalDataField: 'booklbcode',
        dataField: 'booklbcode',
        originalDataFieldType: 'String',
        initValue: '',
        path: 'booklbcode',

        validRules: [
            {
                type: 'maxLength',
                constraints: [36],
                message: '最大长度为36',
            }
        ]
    })
    booklbcode: string;

    @NgField({
        originalDataField: 'Remark',
        dataField: 'remark',
        originalDataFieldType: 'Text',
        initValue: '',
        path: 'Remark',
    })
    remark: any;

    @NgObject({
        dataField: 'billStatus',
        originalDataField: 'BillStatus',
        type: BillState74a9Entity
    })
    billStatus: BillState74a9Entity;
    @NgObject({
        dataField: 'processInstance',
        originalDataField: 'ProcessInstance',
        type: ProcessInstance073bEntity
    })
    processInstance: ProcessInstance073bEntity;
}